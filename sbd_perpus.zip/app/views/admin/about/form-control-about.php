<div class="mb-3">
  <label for="info" class="form-label">Info</label>
  <input type="text" class="form-control" id="info" name="info" required>
</div>

<div class="mb-3">
  <label for="address" class="form-label">Alamat</label>
  <input type="text" class="form-control" id="address" name="address">
</div>

<div class="mb-3">
  <label for="email" class="form-label">Email</label>
  <input type="text" class="form-control" id="email" name="email">
</div>

<div class="mb-3">
  <label for="phone" class="form-label">No Hp</label>
  <input type="text" class="form-control" id="phone" name="phone">
</div>
<button type="submit" class="btn btn-primary">Tambah</button>