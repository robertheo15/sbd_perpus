<div class="mb-3">
  <label for="url" class="form-label">Url</label>
  <input type="text" class="form-control" id="url" name="url" required>
</div>

<div class="mb-3">
  <label for="aClass" class="form-label">a Class</label>
  <input type="text" class="form-control" id="aClass" name="aClass">
</div>

<div class="mb-3">
  <label for="iconClass" class="form-label">Icon Class</label>
  <input type="text" class="form-control" id="iconClass" name="iconClass">
</div>

<div class="mb-3">
  <label for="username" class="form-label">Username</label>
  <input type="text" class="form-control" id="username" name="username">
</div>
<button type="submit" class="btn btn-primary">Tambah</button>