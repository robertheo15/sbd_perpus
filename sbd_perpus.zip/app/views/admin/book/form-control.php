  <div class="mb-3">
    <label for="formFile" class="form-label">Foto cover</label>
    <input class="form-control" type="file" id="formFile" name="formFile">
  </div>

  <div class="mb-3">
    <label for="titleBook" class="form-label">Judul buku</label>
    <input type="text" class="form-control" id="titleBook" name="titleBook" required>
  </div>

  <div class="mb-3">
    <label for="authorName" class="form-label">Penulis</label>
    <input type="text" class="form-control" id="authorName" name="authorName">
  </div>

  <div class="mb-3">
    <label for="yearBook" class="form-label">Tahun terbit</label>
    <input type="date" class="form-control" id="yearBook" name="yearBook">
  </div>

  <div class="mb-3">
    <label for="quantity" class="form-label">Jumlah</label>
    <input type="text" class="form-control" id="quantity" name="quantity">
  </div>

  <div class="mb-3">
    <label for="bookType" class="form-label">Tipe buku</label>
    <input type="text" class="form-control" id="bookType" name="bookType">
  </div>

  <div class="mb-3">
    <label for="bookPrice" class="form-label">Harga</label>
    <input type="text" class="form-control" id="bookPrice" name="bookPrice">
  </div>

  <button type="submit" class="btn btn-primary">Post</button>